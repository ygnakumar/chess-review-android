import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const source = path.join(root, 'node_modules', 'stockfish', 'src');
const target = path.join(root, 'public', 'engine');
fs.mkdirSync(target, { recursive: true });

const files = [
  'stockfish-17.1-lite-single-03e3232.js',
  'stockfish-17.1-lite-single-03e3232.wasm'
];
for (const file of files) {
  const from = path.join(source, file);
  if (!fs.existsSync(from)) {
    throw new Error(`Stockfish asset not found: ${from}. Run npm install first.`);
  }
  fs.copyFileSync(from, path.join(target, file));
}
for (const file of ['Copying.txt', 'AUTHORS']) {
  const from = path.join(root, 'node_modules', 'stockfish', file);
  if (fs.existsSync(from)) fs.copyFileSync(from, path.join(target, file));
}
console.log('Stockfish 17.1 lite single-threaded WASM assets copied to public/engine.');
