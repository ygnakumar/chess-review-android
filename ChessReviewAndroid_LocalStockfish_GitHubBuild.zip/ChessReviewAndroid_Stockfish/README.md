# Chess Review Android — local Stockfish edition

A mobile-first chess game review app that imports PGN text (including PGN copied from Chess.com), replays legal moves with `chess.js`, and evaluates every position using a **bundled local Stockfish 17.1 lite single-threaded WebAssembly engine**. Analysis does not call Lichess or require an internet connection after the app and engine assets are installed.

## Build

Requirements: Node.js 20+, npm, Android Studio with Android SDK, and a JDK supported by the installed Android Gradle plugin.

```bash
npm install
npm run build
npx cap add android       # only the first time
npx cap sync android
npx cap open android
```

In Android Studio, select the app run configuration to test on a device/emulator. For an APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The `postinstall`/`copy-stockfish` script copies the Stockfish JavaScript worker, WASM binary, and license notices from the pinned npm dependency into `public/engine/`. Vite then packages those files into the web assets, and Capacitor copies them into the Android app. This is how the engine is bundled in the built app; the source ZIP keeps the binary reproducible through npm rather than duplicating the 7 MB WASM file in the ZIP.

## Use

1. Copy the PGN from Chess.com (usually from the game's Download/Share PGN option).
2. Paste it into **Import PGN** and choose **Load PGN**.
3. Select **Review this game**. Stockfish analyzes the start position and every position after a move, locally on the device.
4. Navigate the board and choose key moments to inspect the move sequence.

## Notes and limitations

- This is an independent learning app, not affiliated with Chess.com.
- Move classifications and accuracy percentages are heuristics based on centipawn evaluation loss; they are **not** Chess.com's proprietary Game Review algorithm or accuracy score.
- The included Stockfish **lite single-threaded** build is chosen for mobile WebView compatibility and a smaller app size. Deep review can take time on older phones. The current depth is 12 in `src/main.js`; increasing it improves search effort but makes review slower.
- Every position is sent to Stockfish through UCI and analyzed locally. No public evaluation cache is used. A future enhancement could add adjustable depth, cancellation, and per-move progress.
- APK build and on-device verification must be completed in Android Studio on a machine with the Android SDK. This source package has not been represented as a tested APK.

## Stockfish license

Stockfish.js 17.1 is GPLv3-licensed. The build copies the upstream `Copying.txt` and `AUTHORS` files into the app's `public/engine/` directory. If you distribute the app, comply with GPLv3, including the corresponding source-code and license obligations. Upstream project: https://github.com/nmrugg/stockfish.js


## Build an APK without installing Android Studio on your phone

This project includes `.github/workflows/build-apk.yml` for GitHub Actions. To use it:

1. Create a new GitHub repository you control.
2. Upload the **contents** of the `ChessReviewAndroid_Stockfish` folder to the repository root. Ensure `package.json`, `src/`, `scripts/`, and `.github/` are at the root, not nested inside another folder.
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Choose **Run workflow** (or push to `main`/`master`) and wait for the workflow to finish.
5. Open the successful workflow run, scroll to **Artifacts**, and download `chess-review-debug-apk`.
6. Extract that artifact ZIP on your Android phone and tap `app-debug.apk` to install. Android may ask you to allow installs from that source. Only install APKs you built or trust.

This produces a debug APK for testing, not a Play Store release APK. A signed release build requires a signing key and additional configuration.
