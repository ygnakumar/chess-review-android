import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId:'com.chessreview.app', appName:'Chess Review', webDir:'dist', server:{androidScheme:'https'} };
export default config;
