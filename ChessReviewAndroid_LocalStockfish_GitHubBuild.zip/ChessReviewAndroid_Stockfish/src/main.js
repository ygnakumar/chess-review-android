import { Chess } from 'chess.js';
import './style.css';
const $=s=>document.querySelector(s);
const icons={w:{k:'♔',q:'♕',r:'♖',b:'♗',n:'♘',p:'♙'},b:{k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟︎'}};
const sample=`[Event "Italian Game Practice"]
[White "White Player"]
[Black "Black Player"]
[Result "*"]

1. e4 e5 2. Nf3 Nc6 3. Bc4 Bc5 4. c3 Nf6 5. d3 d6 6. O-O O-O *`;
let moves=[],states=[],meta={},ply=0,orientation='w',selected=null,targets=[],review=[],timer=null;
$('#app').innerHTML=`
<header><div class="brand"><span class="logo">♞</span><div><b>CHESS REVIEW</b><small>Your personal game coach</small></div></div><button id="flip" class="outline">⇅ Flip</button></header>
<main><section class="left">
<div class="players panel"><div><i>♔</i><span><b id="white">White</b><small>White</small></span></div><strong>VS</strong><div class="right"><i>♚</i><span><b id="black">Black</b><small>Black</small></span></div></div>
<div class="panel boardpanel"><div class="row spread"><b class="eyebrow">ANALYSIS BOARD</b><span id="turn" class="pill">White to move</span></div><div class="boardrow"><div class="eval"><div id="evalfill"></div><span id="evaltext">—</span></div><div id="board" class="board"></div></div>
<div class="controls"><button id="first">|◀</button><button id="prev">◀</button><button id="play" class="green">▶</button><button id="next">▶</button><button id="last">▶|</button><span id="plylabel">Start position</span></div><div class="progress"><div id="progressfill"></div></div></div>
<div class="panel moves"><div class="row spread"><b class="eyebrow">MOVE LIST</b><small id="movecount">0 plies</small></div><div id="movelist"></div></div>
</section><section class="right">
<div class="hero"><small class="eyebrow">GAME REVIEW</small><h1>Find the move<br><em>that changes everything.</em></h1><p>Explore your game, spot turning points, and learn a stronger continuation.</p><button id="review" class="primary">✦ Review this game</button><div id="status">● Ready to analyze</div></div>
<div class="stats"><div><small>WHITE ACCURACY*</small><b id="wa">—</b></div><div><small>BLACK ACCURACY*</small><b id="ba">—</b></div><div><small>MISTAKES</small><b id="mistakes">—</b></div></div>
<div class="panel insight"><div class="row spread"><b class="eyebrow">MOVE INSIGHT</b><span id="quality" class="pill">READY</span></div><h2 id="title">Your game, move by move</h2><p id="explain">Paste a Chess.com PGN and analyze every position locally with the bundled Stockfish engine.</p><div id="best" class="best hidden"><div><small>BEST CONTINUATION</small><b id="besttext">—</b></div><button id="try" class="outline">Practice</button></div></div>
<div class="panel"><div class="row spread"><b class="eyebrow">KEY MOMENTS</b><small>Engine-evaluated turning points</small></div><div id="moments" class="empty">Review the game to discover turning points.</div></div>
<div class="panel import"><div class="row spread"><b class="eyebrow">IMPORT PGN</b><button id="sample" class="textbtn">Load sample</button></div><textarea id="pgn" spellcheck="false"></textarea><div class="row spread importfoot"><small id="message">PGN is parsed locally. Stockfish analysis runs on this device.</small><button id="load" class="primary">Load PGN</button></div></div>
<footer>Independent chess-learning tool. Not affiliated with Chess.com. Accuracy labels are estimates.</footer>
</section></main><div id="toast"></div>`;
function metadata(p){const h={};for(const m of p.matchAll(/^\[(\w+)\s+"([^"]*)"\]/gm))h[m[1]]=m[2];return{white:h.White||'White',black:h.Black||'Black',event:h.Event||'Imported game',result:h.Result||'*'};}
function parse(pgn){const g=new Chess();g.loadPgn(pgn,{strict:false});const hist=g.history({verbose:true}),r=new Chess(),s=[{fen:r.fen()}];for(const m of hist){const x=r.move({from:m.from,to:m.to,promotion:m.promotion});if(!x)throw Error('Illegal move in PGN');s.push({fen:r.fen(),uci:x.from+x.to+(x.promotion||''),san:x.san});}return{hist,s};}
function gameAt(n){const g=new Chess();for(const m of moves.slice(0,n))g.move({from:m.from,to:m.to,promotion:m.promotion});return g;}
function load(p){try{const parsed=parse(p);moves=parsed.hist;states=parsed.s;meta=metadata(p);ply=0;review=[];selected=null;targets=[];$('#white').textContent=meta.white;$('#black').textContent=meta.black;$('#pgn').value=p;$('#message').textContent=`Loaded ${moves.length} half-moves.`;$('#message').className='good';$('#wa').textContent=$('#ba').textContent=$('#mistakes').textContent='—';$('#moments').textContent='Review the game to discover turning points.';$('#title').textContent='Game loaded';$('#explain').textContent=`${meta.event} · ${meta.white} vs ${meta.black}. Start review to analyze positions.`;render();toast('PGN loaded successfully');}catch(e){$('#message').textContent='PGN error: '+e.message;$('#message').className='bad';}}
function renderBoard(){const g=gameAt(ply),b=g.board(),last=ply?moves[ply-1]:null;$('#board').innerHTML='';const rs=orientation==='w'?[0,1,2,3,4,5,6,7]:[7,6,5,4,3,2,1,0],fs=orientation==='w'?[0,1,2,3,4,5,6,7]:[7,6,5,4,3,2,1,0];for(const r of rs)for(const f of fs){const sq='abcdefgh'[f]+(8-r),p=b[r][f],btn=document.createElement('button');btn.className=`sq ${(r+f)%2?'dark':'light'}${last&&(last.from===sq||last.to===sq)?' last':''}${selected===sq?' selected':''}`;if(targets.includes(sq))btn.classList.add(p?'capture':'target');btn.setAttribute('aria-label',sq+(p?` ${p.color} ${p.type}`:''));if(f===(orientation==='w'?0:7)){const a=document.createElement('small');a.className='rank';a.textContent=8-r;btn.append(a);}if(r===(orientation==='w'?7:0)){const a=document.createElement('small');a.className='file';a.textContent='abcdefgh'[f];btn.append(a);}if(p){const z=document.createElement('span');z.className=p.color==='w'?'whitepiece':'blackpiece';z.textContent=icons[p.color][p.type];btn.append(z);}btn.onclick=()=>clickSquare(sq);$('#board').append(btn);}
$('#turn').textContent=g.isCheckmate()?'Checkmate':g.isDraw()?'Draw':(g.turn()==='w'?'White':'Black')+' to move'+(g.isCheck()?' · Check':'');}
function renderMoves(){const list=$('#movelist');list.innerHTML='';for(let i=0;i<moves.length;i+=2){const row=document.createElement('div');row.className='mrow';const n=document.createElement('span');n.className='num';n.textContent=(i/2+1)+'.';row.append(n);for(let j=i;j<Math.min(i+2,moves.length);j++){const b=document.createElement('button');b.className='mtoken'+(ply===j+1?' active':'');b.textContent=moves[j].san;b.onclick=()=>{ply=j+1;selected=null;targets=[];render();insight();};row.append(b);}list.append(row);}$('#movecount').textContent=moves.length+' plies';$('#plylabel').textContent=ply===0?'Start position':`Move ${Math.ceil(ply/2)} · ${ply%2?'White':'Black'}`;$('#progressfill').style.width=(moves.length?100*ply/moves.length:0)+'%';}
function render(){renderBoard();renderMoves();$('#prev').disabled=$('#first').disabled=ply===0;$('#next').disabled=$('#last').disabled=ply===moves.length;if(review[ply-1])showEntry(review[ply-1]);}
function clickSquare(sq){if(ply!==moves.length){toast('Jump to the final position to explore alternatives.');return;}const g=gameAt(ply),p=g.get(sq);if(selected&&targets.includes(sq)){const ms=g.moves({square:selected,verbose:true}).filter(m=>m.to===sq);let promo=ms[0]?.promotion;if(ms.length>1){promo=(prompt('Promote to q, r, b, or n','q')||'q').toLowerCase();if(!'qrbn'.includes(promo))promo='q';}try{const x=g.move({from:selected,to:sq,...(promo?{promotion:promo}:{})});moves.push(x);const replay=new Chess();states=[{fen:replay.fen()}];for(const m of moves){const a=replay.move({from:m.from,to:m.to,promotion:m.promotion});states.push({fen:replay.fen(),uci:a.from+a.to+(a.promotion||''),san:a.san});}ply=moves.length;review=[];}catch{}selected=null;targets=[];render();return;}if(p&&p.color===g.turn()){selected=sq;targets=g.moves({square:sq,verbose:true}).map(m=>m.to);}else{selected=null;targets=[];}renderBoard();}
function toast(t){const e=$('#toast');e.textContent=t;e.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>e.classList.remove('show'),2400);}
function showEntry(e){$('#quality').textContent=e.label.toUpperCase();$('#title').textContent=e.title;$('#explain').textContent=e.explanation;$('#evaltext').textContent=e.scoreText||'—';$('#evalfill').style.height=(e.share||50)+'%';$('#best').classList.toggle('hidden',!e.bestSan);$('#besttext').textContent=e.bestSan||'No cached best move';}
function insight(){if(review[ply-1])showEntry(review[ply-1]);else if(!ply){$('#title').textContent='Starting position';$('#explain').textContent='Step through the game or run review to see engine feedback.';}}

function classify(loss){
  return loss<=20?'Best / excellent':loss<=55?'Good':loss<=110?'Inaccuracy':loss<=220?'Mistake':'Blunder';
}
let stockfishWorker=null, engineReady=null, activeAnalysis=null, analysisDepth=12;
function engineAsset(name){return new URL(`engine/${name}`, document.baseURI).toString();}
function ensureEngine(){
  if(engineReady)return engineReady;
  engineReady=new Promise((resolve,reject)=>{
    try{
      stockfishWorker=new Worker(engineAsset('stockfish-17.1-lite-single-03e3232.js'));
      const timeout=setTimeout(()=>reject(new Error('Stockfish did not initialize. Try reopening the app.')),20000);
      const onMessage=e=>{
        const line=String(e.data||'').trim();
        if(line==='uciok'){
          stockfishWorker.postMessage('setoption name Threads value 1');
          stockfishWorker.postMessage('isready');
        }else if(line==='readyok'){
          clearTimeout(timeout);
          stockfishWorker.removeEventListener('message',onMessage);
          resolve(stockfishWorker);
        }
      };
      stockfishWorker.addEventListener('message',onMessage);
      stockfishWorker.postMessage('uci');
      stockfishWorker.addEventListener('error',e=>{
        clearTimeout(timeout); reject(new Error('Stockfish worker failed to load: '+(e.message||'unknown error')));
      },{once:true});
    }catch(e){reject(e);}
  });
  return engineReady;
}
function analyzeFen(fen, depth, progress){
  return new Promise(async (resolve,reject)=>{
    try{
      const worker=await ensureEngine();
      if(activeAnalysis?.cancelled) return reject(new Error('Analysis cancelled'));
      let latest=null, finished=false;
      const finish=(value,error)=>{
        if(finished)return;
        finished=true; clearTimeout(timeout);
        worker.removeEventListener('message',onMessage);
        if(activeAnalysis?.finish===finish)activeAnalysis=null;
        error?reject(error):resolve(value);
      };
      const onMessage=e=>{
        const line=String(e.data||'').trim();
        if(line.startsWith('info ')){
          const depthMatch=line.match(/\bdepth\s+(\d+)/);
          const scoreMatch=line.match(/\bscore\s+(cp|mate)\s+(-?\d+)/);
          const pvMatch=line.match(/\bpv\s+(.+)$/);
          if(scoreMatch){
            latest={
              depth:depthMatch?Number(depthMatch[1]):0,
              cp:scoreMatch[1]==='cp'?Number(scoreMatch[2]):(Number(scoreMatch[2])>0?10000:-10000),
              mate:scoreMatch[1]==='mate'?Number(scoreMatch[2]):undefined,
              pv:pvMatch?pvMatch[1].trim():''
            };
          }
          if(depthMatch&&progress)progress(Number(depthMatch[1]));
        }else if(line.startsWith('bestmove ')){
          const bm=line.split(/\s+/)[1];
          finish(latest?{...latest,bestmove:bm}:null);
        }
      };
      const timeout=setTimeout(()=>{worker.postMessage('stop');finish(latest||null);},90000);
      activeAnalysis={cancelled:false,finish};
      worker.addEventListener('message',onMessage);
      worker.postMessage('position fen '+fen);
      worker.postMessage('go depth '+depth);
    }catch(e){reject(e);}
  });
}
function scoreWhite(score,fen){
  if(!score)return null;
  const sideToMove=(fen.split(/\s+/)[1]||'w');
  return score.cp*(sideToMove==='w'?1:-1);
}
function uciToSan(fen,uci){
  if(!uci||uci.length<4)return '';
  try{
    const g=new Chess(fen);
    return g.move({from:uci.slice(0,2),to:uci.slice(2,4),promotion:uci[4]} )?.san||uci;
  }catch{return uci;}
}
async function doReview(){
  if(!moves.length)return toast('Load a PGN first.');
  $('#review').disabled=true;$('#review').textContent='Analyzing locally…';
  $('#status').textContent='Starting bundled Stockfish engine…';
  review=[];
  const scores=[];
  try{
    await ensureEngine();
    for(let i=0;i<states.length;i++){
      $('#status').textContent=`Stockfish analyzing position ${i+1}/${states.length} · depth ${analysisDepth}`;
      const result=await analyzeFen(states[i].fen,analysisDepth,()=>{});
      if(!result){scores.push(null);continue;}
      scores.push({...result,whiteCp:scoreWhite(result,states[i].fen)});
      // Yield to the UI between positions; all analysis stays on-device.
      await new Promise(r=>setTimeout(r,0));
    }
    review=moves.map((m,i)=>{
      const before=scores[i],after=scores[i+1],fenBefore=states[i].fen;
      if(!before||!after)return{label:'Analysis unavailable',title:`${i+1}. ${m.san}`,explanation:'Stockfish did not return a score for this position. No external cache was used.',share:50};
      const loss=Math.max(0,m.color==='w'?before.whiteCp-after.whiteCp:after.whiteCp-before.whiteCp);
      const label=classify(loss),bestSan=uciToSan(fenBefore,before.bestmove);
      const cp=after.whiteCp;
      const scoreText=after.mate!==undefined?`M${after.mate}`:(cp>=0?'+':'')+(cp/100).toFixed(2);
      return{
        label,title:`${m.color==='w'?'White':'Black'}: ${m.san} · ${label}`,
        explanation:`${m.color==='w'?'White':'Black'} played ${m.san}. Estimated evaluation loss: ${(loss/100).toFixed(2)} pawns, compared with the position before the move. Engine depth ${analysisDepth}; labels and accuracy estimates are independent estimates, not Chess.com's proprietary scores.`,
        cp,scoreText,share:Math.max(4,Math.min(96,50+cp/16)),
        bestUci:before.bestmove,bestSan,loss
      };
    });
    const avg=arr=>arr.length?Math.round(arr.reduce((s,x)=>s+Math.max(0,100-Math.min(100,x.loss||0)/4),0)/arr.length):null;
    const w=review.filter((x,i)=>moves[i].color==='w'&&x.label!=='Analysis unavailable');
    const b=review.filter((x,i)=>moves[i].color==='b'&&x.label!=='Analysis unavailable');
    $('#wa').textContent=avg(w)===null?'—':avg(w)+'%';
    $('#ba').textContent=avg(b)===null?'—':avg(b)+'%';
    $('#mistakes').textContent=review.filter(x=>['Mistake','Blunder','Inaccuracy'].includes(x.label)).length;
    const holder=$('#moments');holder.innerHTML='';
    const key=review.map((x,i)=>({...x,i})).filter(x=>['Mistake','Blunder','Inaccuracy'].includes(x.label)).sort((a,b)=>(b.loss||0)-(a.loss||0)).slice(0,5);
    if(!key.length)holder.textContent='No evaluated mistakes found at this depth. Try a higher depth for a slower, potentially stronger review.';
    for(const x of key){
      const el=document.createElement('button');el.className='moment';
      const title=document.createElement('b');title.textContent=`${x.i+1}. ${x.title}`;
      const detail=document.createElement('small');detail.textContent=x.explanation;
      const label=document.createElement('span');label.textContent=x.label;
      el.append(title,detail,label);el.onclick=()=>{ply=x.i+1;render();};holder.append(el);
    }
    $('#status').textContent=`Review finished · ${moves.length} moves analyzed locally by Stockfish · depth ${analysisDepth}`;
    $('#review').textContent='↻ Review again';
    render();
    if(key.length)toast('Local Stockfish review complete.');
  }catch(e){
    $('#status').textContent='Engine error: '+e.message;
    $('#title').textContent='Could not start local engine';
    $('#explain').textContent='The review does not contact Lichess. Check that npm install and the Android build copied the Stockfish engine assets, then rebuild.';
    toast('Stockfish error. See review status.');
  }finally{
    $('#review').disabled=false;
  }
}
$('#load').onclick=()=>load($('#pgn').value.trim());$('#sample').onclick=()=>{ $('#pgn').value=sample;load(sample);};$('#review').onclick=doReview;$('#flip').onclick=()=>{orientation=orientation==='w'?'b':'w';renderBoard();};$('#first').onclick=()=>{ply=0;selected=null;targets=[];render();insight();};$('#prev').onclick=()=>{ply=Math.max(0,ply-1);selected=null;targets=[];render();insight();};$('#next').onclick=()=>{ply=Math.min(moves.length,ply+1);selected=null;targets=[];render();insight();};$('#last').onclick=()=>{ply=moves.length;selected=null;targets=[];render();insight();};$('#play').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('#play').textContent='▶';return;}$('#play').textContent='Ⅱ';timer=setInterval(()=>{if(ply>=moves.length){clearInterval(timer);timer=null;$('#play').textContent='▶';return;}ply++;render();},850);};$('#try').onclick=()=>toast('Practice mode: use the board to explore legal continuations.');$('#pgn').value=sample;load(sample);
