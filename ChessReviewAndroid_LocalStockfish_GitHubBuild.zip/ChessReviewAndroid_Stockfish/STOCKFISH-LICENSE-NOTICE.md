# Bundled engine notice

This app build downloads Stockfish.js 17.1.0 from the npm package `stockfish` and copies the mobile-compatible `stockfish-17.1-lite-single-03e3232.js` and `.wasm` assets into the app's packaged assets.

Stockfish.js is licensed under GNU GPL version 3.0. The build copies the upstream `Copying.txt` and `AUTHORS` notices into `public/engine/` when `npm install` or `npm run copy-stockfish` is run. If distributing binaries, provide the corresponding source and comply with GPLv3.

Upstream: https://github.com/nmrugg/stockfish.js
